import string
a='cat'
b='lorem ipsum dolor sit amet, consectetuer adipiscing elit. nam cursus. morbi ut mi. nullam enim leo, egestas id, condimentum at, laoreet mattis, massa. sed eleifend nonummy diam. praesent mauris ante, elementum et, bibendum at, posuere sit amet, nibh. duis tincidunt lectus quis dui viverra vestibulum. suspendisse vulputate aliquam dui. nulla elementum dui ut augue. aliquam vehicula mi at mauris. maecenas placerat, nisl at consequat rhoncus, sem nunc gravida justo, quis eleifend arcu velit quis lacus. morbi magna magna, tincidunt a, mattis non, imperdiet vitae, tellus. sed odio est, auctor ac, sollicitudin in, consequat vitae, orci. fusce id felis. vivamus sollicitudin metus eget eros.'

c=''

i=0
k=0
while i <= (len(b)-1):
   if k == (len(a)):
      k=0
   c+='\\x'+hex((ord(a[k])^ord(b[i])))


   k+=1
   i+=1

h=0
j=0
q=''
n=0


c = c.replace('xa','\\n')#'xA')
c= c.replace('xd','\\r')#'xD')
c = c.replace('x9', '\\t')#,'x9')
c=c.replace('0x','')

#while h <= (len(b)-1):
#   if j == (len(c)-1):
#      j=0
#   q+=chr(ord(b[h])^ord(c[j]))
#   j+=1
#   h+=1
   

print (c)
print (q)

print (hex(ord('\r')),hex(ord('\n')), hex(ord('\t')), hex(ord(' ')), chr(16))