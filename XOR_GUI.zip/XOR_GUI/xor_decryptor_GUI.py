#Dustin Matt & Dakota Fuller

#XOR Decryption
import sys
import string
from easygui import *
from XOR_Shifter import *
from Mod_shifter import *


def show_intro():
    msgbox("This program decrypts XOR encrypted files.")
  

def shifter_display(crypt):
    textbox(msg='Find the pattern that is a multiple of the key length.', title='Shift results.', text=str(shifter(crypt)) ,codebox=0)
    
def mod_shifter_display(crypt):
    keylength = enterbox("Input the key length:")
    if keylength == None or keylength != int:
        msgbox('Must enter a number.')
    else:
        plaintext = mod_shifter(crypt, int(keylength)) # Contains the possible plain text choices for x positions in the test where x is the key length.    
        common = [None]*int(keylength) #This dictionary contains each unique character in the plain text indexes and how many times it occured at that index.
        i=0
       
        while i <= (len(plaintext)-1):
            
            a=0 # used to iterate through the rest of the list in search
            
            alpha = list(string.ascii_lowercase) #Alphabet list
            found=[] # Displays how many occurences of each letter is in a position
            
            while a <= (len(alpha)-1):
                count = 0
                y=0 # Iterates through the tuples in a given character position 'i'
                while y <= (len(plaintext[i])-1):
                            
                    if alpha[a] == plaintext[i][y][0]:
                        count+=1
                            
                    if alpha[a] == plaintext[i][y][1]: 
                        count+=1                      
                        
                    y+=1
                if count > 0:
                    found.append(str(count)+':'+alpha[a])
                a+=1
            common[i]=found
            common[i].sort(reverse=True) # Sorts the highest occurences to the front of the list
            i+=1
            
        formatted =''
        h=0
        while h <= (len(common)-1):
            formatted += 'Possible letters for postition '+ str(h) + ': ' + str(common[h])+'\n'+'\n'
            h+=1
            
        codebox(msg='These are the characters that could be found in the first '+keylength+' characters of the plain text.', title='Frequency of Occurence', text=(formatted))
            
        

def withKey(crypt):

        key = ''
                
        key = enterbox("Input password or key:")
        if key == '':
            msgbox ("Key cannot be empty","Invalid Input")
        elif key == None:
            msgbox("Returning to main menu.")
                
        else:

            result =[]
            asc_key=[]
            out=''
            n=1
            i=0
            p=0
            I=0
            j=0
            
            crypt = crypt.replace('n','xA')
            crypt = crypt.replace('r','xD')
            crypt = crypt.replace('t','x9')
            
            result = crypt.split('\\x')    
            
    
            while p <= len(key)-1:
    
                asc_key.append(ord(key[p]))
                p+=1
            
        
            while n <= len(result)-1:
                result[n]= chr((asc_key[i])^(int(result[n],16)))
                n+=1
                if i == (len(key)-1):
                    i = 0
                else: i+=1
            
            while I <= len(result)-1:
                out+= (result[I])
                I+=1
            msgbox (out,"The correspondant of that key or password is:")

    

            
            
def get_main_menu_option():
        option = ''
        while option is '' :
            selection = choicebox(msg="Select an action",
                        choices=('1 Decyption Without A Key Length', \
                                   '2 Decyption With A Key Length', \
                                   '3 Decyption With A Key', \
                                   '4 Quit'))
            if selection is not None :
                option = selection.split()[0]
            else: option = None
        return option    
    

def main():
    show_intro()
    
    crypt = ''
    while crypt == '':
        crypt = enterbox("Input xor encryption:")
        if crypt == None:
            sys.exit()
    
    option = ''
    while 1 :
        option = get_main_menu_option()
        if option == '1':
            shifter_display(crypt)
        elif option == '2':
            mod_shifter_display(crypt)
        elif option == '3':
            withKey(crypt)    
        elif option == '4' or option == None:
            sys.exit()

main()

    
    